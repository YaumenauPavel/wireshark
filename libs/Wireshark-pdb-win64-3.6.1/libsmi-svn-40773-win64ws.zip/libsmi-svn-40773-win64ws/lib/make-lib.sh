#!/bin/sh

lib /machine:x64 /def:smi.def /name:libsmi-2.dll /out:libsmi-2.lib
